#!/bin/bash
# Script de Disco — Tooltip estável e com formatação Gb/Mb

MAIN_MOUNT="/"
EXCLUDED_TYPES="tmpfs|devtmpfs|squashfs|ramfs|overlay|cgroup|udev|proc|sys|securityfs|efivarfs|pstore"

# ÍCONES (Nerd Font)
ICON_MAIN="󰋊"  # Ícone padrão/principal
ICON_HOME="󰋜"  # Para /home
ICON_USB="󰦥"   # Para Mídia Removível
ICON_HDD="󰋇"   # Para Outros Discos/Partições
ICON_BOOT="󰻀"  # Para /boot

# =========================================================
# 🔹 FUNÇÃO DE SUBSTITUIÇÃO DE UNIDADES 🔹
# =========================================================

# Função para substituir a unidade curta pela unidade longa (G -> Gb, M -> Mb)
format_unit() {
    local value="$1"
    
    # Substitui G por Gb
    value="${value/G/Gb}"
    # Substitui M por Mb
    value="${value/M/Mb}"
    # Substitui T por Tb
    value="${value/T/Tb}"
    # Substitui K por Kb (para valores muito pequenos)
    value="${value/K/Kb}"
    
    echo "$value"
}

# Coleta de discos, usando o filtro df -x para estabilidade
DISK_DATA=$(df -h -x tmpfs -x devtmpfs -x squashfs -x ramfs -x overlay -x cgroup2 -x proc -x sysfs -x udev -x pstore -x efivarfs 2>/dev/null | awk 'NR>1 {print $6, $3, $4, $2}')

# --- DISCO PRINCIPAL ---
MAIN_DATA=$(echo "$DISK_DATA" | awk -v M="$MAIN_MOUNT" '$1 == M {print $2, $3, $4}')
USED_MAIN=$(echo "$MAIN_DATA" | awk '{print $1}') 
FREE_MAIN=$(echo "$MAIN_DATA" | awk '{print $2}')
TOTAL_MAIN=$(echo "$MAIN_DATA" | awk '{print $3}')

# Aplica a formatação nas variáveis principais
USED_MAIN_LONG=$(format_unit "$USED_MAIN")
FREE_MAIN_LONG=$(format_unit "$FREE_MAIN")
TOTAL_MAIN_LONG=$(format_unit "$TOTAL_MAIN")

# Texto principal do Waybar: Apenas o valor formatado
WAYBAR_TEXT="$USED_MAIN_LONG"

# --- TOOLTIP DO DISCO PRINCIPAL (Alinhamento Corrigido) ---
TOOLTIP="${ICON_MAIN} DISCO PRINCIPAL (${MAIN_MOUNT})\n"
TOOLTIP+="Usado : $USED_MAIN_LONG\n"
TOOLTIP+="Livre : $FREE_MAIN_LONG\n"
TOOLTIP+="Total : $TOTAL_MAIN_LONG\n\n"
TOOLTIP+="${ICON_MAIN} OUTROS DISCOS:\n"

# --- LOOP PARA OUTROS DISCOS ---
while read -r MOUNT USED FREE TOTAL; do
    [[ "$MOUNT" == "$MAIN_MOUNT" ]] && continue

    NAME=$(basename "$MOUNT")
    [[ -z "$NAME" ]] && NAME="$MOUNT"
    
    # Aplica a formatação DENTRO do loop para o tooltip
    USED_LONG=$(format_unit "$USED")
    TOTAL_LONG=$(format_unit "$TOTAL")

    # Sua lógica de ícones personalizada
    if [[ "$MOUNT" == "/home" ]]; then
        ICON="$ICON_HOME"
    elif [[ "$MOUNT" == "/boot" ]]; then
        ICON="$ICON_BOOT"
    elif [[ "$MOUNT" == *"run/media"* ]]; then
        ICON="${ICON_USB}" 
    else
        ICON="${ICON_MAIN}" 
    fi

    # Linha final do Tooltip (usando as variáveis formatadas)
    TOOLTIP+="${ICON} ${NAME}: ${USED_LONG}/${TOTAL_LONG}\n"
done <<< "$DISK_DATA"

# --- ESCAPA PARA JSON (Método Simples e Confiável) ---
ESCAPED_TOOLTIP=$(echo "$TOOLTIP" | sed ':a;N;$!ba;s/\n/\\n/g; s/"/\\"/g' | tr -d '\r')

# --- SAÍDA FINAL (Máxima Estabilidade) ---
echo "{\"text\": \"$WAYBAR_TEXT\", \"tooltip\": \"$ESCAPED_TOOLTIP\"}"