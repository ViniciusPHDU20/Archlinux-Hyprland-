Version 1.2.1
* Fixed utf8 character count

Version 1.2.0
+ Now counts lines
+ Added Support for counting lines, words and characters in selection
