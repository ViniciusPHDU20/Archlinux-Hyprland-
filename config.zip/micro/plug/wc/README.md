# Micro Word Count Plugin

Word, character and line counter for micro editor.
(forked from https://github.com/adamnpeace/micro-wc-plugin)