# Fish Plugin for Micro

This repository holds the fish plugin for micro.

Install with `> plugin install fish`. This plugin will let you automatically run
`fish_indent` from within micro.
