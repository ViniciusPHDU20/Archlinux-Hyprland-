# Quoter Plugin

## Enable Plugin

Once installed, enable the plugin by setting quoter.enable to on

`set quoter.enable on`

## Use

Select some text and press a quote or bracket button to surround the 
selected text with quotes or matching brackets.
