# Misspell Plugin for Micro

This repository holds the misspell plugin for micro.

Install with `> plugin install misspell`,
https://github.com/client9/misspell needs to be in your PATH.
This plugin will lint text for spelling mistakes.
